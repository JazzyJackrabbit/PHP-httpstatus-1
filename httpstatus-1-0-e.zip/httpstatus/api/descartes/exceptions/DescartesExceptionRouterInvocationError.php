<?php

    class DescartesExceptionRouterInvocationError extends Exception {};
    
