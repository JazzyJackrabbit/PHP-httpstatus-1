<?php

    class DescartesExceptionRouterUrlGenerationError extends Exception {};
    
