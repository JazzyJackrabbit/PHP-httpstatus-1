<?php

    class DescartesExceptionConsoleInvocationError extends Exception {};
    
