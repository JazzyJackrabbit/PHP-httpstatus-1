<?php

    class DescartesException404 extends Exception {};
    
