<?php

    class DescartesExceptionTemplateNotReadable extends Exception {};
    
