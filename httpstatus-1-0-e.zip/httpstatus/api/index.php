<?php

	header('Content-Type: application/json');
	
	require("../fonctions/list.php");
	
	$version = 1;
	
	$websites = "[";

	$cmpt = 0;
	foreach($result as $value){

		$idV = $value[0];
		$urlV = $value[1];

		$website = ('{
		"id":'.$idV.',
		"url": "'.$urlV.'",
		"delete": "localhost/httpstatus/api/delete/'.$idV.'",
		"status": "localhost/httpstatus/api/status/'.$idV.'",
		"history": "localhost/httpstatus/api/history/'.$idV.'"
		}');

		if($cmpt<sizeof($result)-1){
			$website .= ",";
		}

		$cmpt += 1;

		$websites .= $website;

	}

	$websites .= "]";

	

	$data = ('{
		"version":'.$version.',
		"websites":'.$websites.'
	}');

	echo $data;

