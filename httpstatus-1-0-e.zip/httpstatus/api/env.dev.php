<?php
	/*
		Ce fichier défini les constantes modifiables et les options
	*/

	//On défini l'environment
    $env = [
        'DATABASE_HOST' => 'localhost',
        'DATABASE_NAME' => 'CASTAING_FERREIRA',
        'DATABASE_USER' => 'root',
        'DATABASE_PASSWORD' => 'bernardbernard',
    ];
