<?php
	/*
		Ce fichier défini les constantes modifiables et les options
	*/

	//On défini l'environment
    $env = [
        'ENV' => 'dev',
        'SESSION_NAME' => 'descartes',
    ];
