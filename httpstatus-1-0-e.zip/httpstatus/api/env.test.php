<?php
	/*
		Ce fichier défini les constantes modifiables et les options
	*/

	//On défini l'environment
    $env = [
    ];
