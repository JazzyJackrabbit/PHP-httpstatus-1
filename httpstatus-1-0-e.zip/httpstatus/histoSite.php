<?php 

	/*
	    EDIT: CASTAING Alexandre
     	DATE: 10-02-2019
		Ce fichier affiche l'historique de l'état du site par son id sur le navigateur
		parametre: $_GET['id']
	*/

	//récupere uniquement l'id du site 
	$id = $_GET['id'];

	//si on parvient à aller sur le site sans id, alors -1
	if($id == null || $id == ""){$id = -1;}

	//connection BDD
	require("fonctions/connectionBDD.php");

	//résultat SQL pour l'historique du site par l'id
	$resultatHistorique = "";

	// résultat SQL pour le nom du site par l'id
	$resultatName = "";

	// effectue les requetes vers la BDD
	try{

		// 1. historique du site
        $requeteHistorique = "SELECT * FROM `Etats` WHERE idSite = ".$id." ORDER BY time DESC LIMIT 500;";

        $sthHistorique = $bdd->prepare($requeteHistorique);
        $sthHistorique->execute();

        $resultatHistorique = $sthHistorique->fetchAll();

        // 2. nom du site
		$requeteName = "SELECT site FROM `Liste` WHERE id = ".$id.";";

        $sthName = $bdd->prepare($requeteName);
        $sthName->execute();

        $resultatName = $sthName->fetchAll();
        
     }catch(PDOException  $e ){

        echo "erreur sql..";

     }

	// Affichage HTML

     ?>

	<meta charset="UTF-8">
	<html>

		<head>
	 		 <link rel="stylesheet" type="text/css" href="form.css">
	 		 <script src="jquery/jquery-3.3.1.min.js"></script>
		</head> 

		<body style='width:100%;'>

				<a href="index.php">Retour</a>

			     
			     <?php 

			     	// //  Affiche le nom

			     	echo "<div style='margin:15px;font-size:150%;'>";
			     	echo $resultatName[0][0];
			     	echo "</div>";

			     	// //  Affiche l'historique

					foreach ($resultatHistorique as $value) {

						echo "<div style='width:100%;text-align:center;font-size:2.8vw;;'>";
						echo "<span style='float:left;width:65%;min-width:80px;text-align:center;'>".$value[3]."</span>";
						echo "<span style='float:right;width:35%;text-align:left;'>".$value[2]."</span>";
						echo "</div>";
					}

				?>
				
		</body>
	
	</html>


