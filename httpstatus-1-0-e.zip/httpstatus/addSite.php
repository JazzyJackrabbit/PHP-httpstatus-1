<?php 

 	/*
      EDIT: CASTAING Alexandre
      DATE: 10-02-2019
      Ce fichier affiche la page d'ajout d'un site.
      Il permet d'ajouter un site à la Base de Données.
      Parametres: 
      	$_POST["addr"], 
      	$_GET['submit']

      Lorsque $_GET['submit'] est à true, on effectue l'ajout dans la BDD avec le site $_POST["addr"]
      
      Administrateur seulement
   */

	session_start();

	if($_SESSION['connect'] != true){

		echo "Page Administrateur, veuillez vous connectez <a href='connection.php'>ici</a>.";

	}else{

		?>

		<meta charset="UTF-8">
		<html>

			<head>
		 		 <link rel="stylesheet" type="text/css" href="form.css">
		 		 <script src="jquery/jquery-3.3.1.min.js"></script>
			</head> 

			<body>

				<a class="acc" href="index.php">accueil</a>
				
				<otherDiv>

					<form action="addSite.php?submit=true" method="post">

						<div>Ajouter un site  (www...), (ip) ou (ip:port). </div>

						</br> <div style="font-size:80%;"> Adresse du site / Nom de domaine: </div>

						<input id="addr" name="addr" style="width:45vw;height:42px;" ></input> 

						</br>
						</br>

						<button id="submit" name="submit" type="submit">Ajouter</button>

						</br>
						</br>

						<?php 
							if($_GET['submit']==true){
								echo "Ajout du site '".$_POST['addr']."' en cours.";
							}
						?>

					</form>

				</otherDiv>

			</body>

		</html>

		<?php

		//si on viens de cliquer sur le bouton un site:

		if($_GET['submit']==true){

			//$_POST["addr"]

			require("fonctions/connectionBDD.php");

			// se connecte à la bdd

			//requete ajout de la liste dans la bdd

			try{

				$flagt = $_POST["addr"]; // TODO: Flags !!!

				$requete = "INSERT INTO `Liste` (Site) VALUES ('".$flagt."');";

				$sth = $bdd->prepare($requete);
				$sth->execute();

			}catch(PDOException  $e ){

				echo 'Erreur : ' . $e->getMessage();
				
			}

		}

	}
