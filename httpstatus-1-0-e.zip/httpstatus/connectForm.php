<!-- Formulaire de Connection -->

<form action="connection.php?submit=true" method="post">

	<div>Connection Administrateur</div>

	</br> <div style="font-size:80%;"> Mail: </div>

	<input id="pseudo" name="pseudo"></input> 

	</br> <div style="font-size:80%;"> Mot de passe: </div>

	<input type="Password" id="mdp" name="mdp"></input>

	</br>
	</br>

	<button id="submit" name="submit" type="submit">Connection</button>

	</br>

</form>