<?php 

 	/*
      EDIT: CASTAING Alexandre
      DATE: 10-02-2019
      Ce fichier affiche la page de modification d'un site choisit.
      Il permet de modifier un site à la BDD.
      Parametres: 
      	$_POST["addr"], 
      	$_GET['submit']

      Lorsque $_GET['submit'] est à true, on effectue la modification du site $_POST["addr"] dans la BDD
      
      Administrateur seulement
   */

	session_start();

	if($_SESSION['connect'] != true){

		echo "Page Administrateur, veuillez vous connectez <a href='connection.php'>ici</a>.";

	}else{

		if($_GET['submit']==false){

		?>

		<meta charset="UTF-8">
		<html>

			<head>
		 		 <link rel="stylesheet" type="text/css" href="form.css">
		 		 <script src="jquery/jquery-3.3.1.min.js"></script>
			</head> 

			<body>

				<a class="acc" href="index.php">accueil</a>
				
				<otherDiv>

					<form action="changeSite.php?submit=true" method="post">

						<!-- re récupere l'id -->

						<input style="display:none;" name="valeur" value="<?php echo $_POST["valeur"];?>"/>

						<div>Modifier le site</div>

						</br> <div style="font-size:80%;"> Adresse du site / Nom de domaine: </div>

						<input id="addr" name="addr" style="width:45vw;height:42px;" ></input> 

						</br>
						</br>

						<button id="submit" name="submit" type="submit">Modifier</button>

						</br>

					</form>

				</otherDiv>

			</body>

		</html>

		<?php

		//si on viens de cliquer sur le bouton un site:

		}else{


			?>

			<meta charset="UTF-8">
			<html>

				<head>
			 		 <link rel="stylesheet" type="text/css" href="form.css">
			 		 <script src="jquery/jquery-3.3.1.min.js"></script>
				</head> 

				<body>

					<a class="acc" href="index.php">accueil</a>
					
					<otherDiv>

						<div style='display:block;'> 
							<div>Le lien a bien été modifié.</div>
							<a href="index.php">Retour</a>
						</div>

					</otherDiv>

				</body>

			</html>

			<?php

			//$_POST["addr"]

			// se connecte à la bdd
			require("fonctions/connectionBDD.php");
			
			
			//requete ajout de la liste dans la bdd

			try{

				$flag = $_POST["addr"]; // TODO: Flags !!!
				$id = $_POST["valeur"]; // TODO: Flags !!!

				$requete = "UPDATE `Liste` SET `Site` = '".$flag."' WHERE id = ".$id.";";

				$sth = $bdd->prepare($requete);
				$sth->execute();

			}catch(PDOException  $e ){

				echo 'Erreur : ' . $e->getMessage();
				
			}

		}

	}
				
	echo "<script>";
	echo 'document.getElementById("addr").value = "'.$_POST['name'].'";';
	echo "console.log('loaded');";
	echo "</script>";

?>