<?php 

	/*
      EDIT: CASTAING Alexandre
      DATE: 10-02-2019
      Ce fichier supprime un site de la BDD et affiche que le site a bien été supprimé sur le navigateur.
	  Les parametres attendus sont:
	  	$_POST['valeur']   (il s'agit de l'id du site)
	  Administrateur Seulement
   */

	session_start();

	if($_SESSION['connect'] != true){

		//si l'administrateur n'est pas connecté

		echo "Page Administrateur, veuillez vous connectez <a href='connection.php'>ici</a>.";

	}else{

		//si l'administrateur est connecté

		// se connecte à la bdd
		require("fonctions/connectionBDD.php");

		 //supprime l'element par l'id dans   $_POST['valeur'];
		try{

			$requete = "DELETE FROM `Liste` WHERE `id` = ". $_POST['valeur'].";";

			$sth = $bdd->prepare($requete);
			$sth->execute();

			echo "<div style='font-size:28px;'>";
			echo "Le lien a bien été supprimé ! <br>";
			echo "</div>";

		}catch(PDOException  $e ){

			echo "erreur sql (lien)..";

		}

		//retire l'historique du site correspondant (par l'id):

		try{

			$requete = "DELETE FROM `Etats` WHERE `idSite` = ". $_POST['valeur'].";";

			$sth = $bdd->prepare($requete);
			$sth->execute();

			echo "<div style='font-size:28px;'>";
			echo "L'historique de l'état du site à bien été retiré également. <br>";
			echo "</div>";

		}catch(PDOException  $e ){

			echo "erreur sql (historique)..";

		}

		echo '<a href="index.php">Retour</a>';

	}