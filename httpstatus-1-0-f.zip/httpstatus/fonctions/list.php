<?php

 	/*
      EDIT: CASTAING Alexandre
      DATE: 10-02-2019
      Ce fichier se connecte et effectue une requete vers la BDD. 
      Il récupere toutes les informations de la table Liste à savoir:
      - Le lien du site [position 1]
      - L'id [position 0]
   */
      
// connection BDD

require("connectionBDD.php");

try{

	$requete = "SELECT * FROM `Liste`";

	$sth = $bdd->prepare($requete);
	$sth->execute();

	$result = $sth->fetchAll();

	// TODO: Selectionner les données par rapport au nom de la colonne et non pas l'emplacement

}catch(PDOException  $e ){

	echo "Error: ".$e;

}	