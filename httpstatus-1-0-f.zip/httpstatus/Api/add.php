<?php

	//header('Content-Type: application/json');
	
	echo $_GET["url"]
;
