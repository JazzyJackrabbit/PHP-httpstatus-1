<?php

   /*
      EDIT: CASTAING Alexandre
      DATE: 10-02-2019
      Ce fichier effectue un ping en fonction des parametres ajax indiqué:
         $_POST["serveur"],
         $_POST["idList"]
      Il retourne un objet json de type: {'id': id_du_site ,'code': code_err_du_site }
      Ce fichier n'a aucun lien avec 'pingCRON'.
      Le ping effectué permet de récuperer le code d'erreur uniquement.
   */

// On utilise Ajax
header("Content-Type: application/json", true);

// récupere les valeurs POST
$server = $_POST["serveur"]; 
//        $_POST["idList"]

// retire 'http://', 'https://' et le dernier '/'
if(substr($server,0,7)=="http://"){
	$server = substr($server,7);
}
if(substr($server,0,8)=="https://"){
	$server = substr($server,8);
}
if(substr($server,-1)=="/"){
	$server = substr($server,0,-1);
}

//retourne la valeur et affichage echo (effectue un ping)
echo sockAccess("");


//retourne le code d'erreur aprés la connection à un site 
function sockAccess($page)
{
   //erreur gestion
   $errno="";
   $errstr="";
   $fp=0;

   //la valeur du site à ping (str)
   global $server;
   $fp=fsockopen($server,80,$errno,$errstr,30);

   if($fp===0) //connection
   {
      die("Error $errstr ($errno)");
   }
   $out="GET /$page HTTP/1.1\r\n";
   $out.="Host: $server\r\n";
   $out.="Connection: Close\r\n\r\n";

   fwrite($fp,$out);
   $content=fgets($fp);
   $code=trim(substr($content,9,4));
   fclose($fp);

   // objet retour avec l'id du site et le code (json stringifié)
   return ('{"id":'.$_POST["idList"].',"code":'.intval($code).'}');
}

?>
