<?php

 	/*
      EDIT: CASTAING Alexandre
      DATE: 10-02-2019
      Ce fichier affiche la page de connection/deconnection d'un utilisateur.
      Il cherche les utilisateurs dans la base de données et compare les identifiants avec ceux de la base de données.
      Détermine alors si il y a connection ou non.      
   */

	session_name('connection');
	session_start();

	$_SESSION['connect'] = $_SESSION['connect'] ?? false;
	$_SESSION['pseudo'] = $_SESSION['pseudo'] ?? null;

?>

<meta charset="UTF-8">
<html>

	<head>
 		 <link rel="stylesheet" type="text/css" href="form.css">
 		 <script src="jquery/jquery-3.3.1.min.js"></script>
	</head> 

	<body>
		
		<a class="acc" href="index.php">accueil</a>

		<connectionDiv>

			<div style="display:block">

				<?php 

					if($_SESSION['connect'] == false){
						if($_GET['submit']==true){

							//tests et valide la connection
							// + SESSION true
							// + redirection

							echo "Connection...";

							$valideConnection = false;
							$erreurConnection = "Impossible de se connecter...";


							// se connecte à la bdd
							require("connectionBDD.php");

							//requete des utilisateurs

							try{

								$requete = "SELECT * FROM `Utilisateurs`";

								$sth = $bdd->prepare($requete);
								$sth->execute();

								$result = $sth->fetchAll();

								//liste les utilisateurs / TODO: remplacer l'emplacement des colonnes par le nom (mysql)
								foreach ($result as &$value) {
							    	if($value[1]===$_POST["pseudo"]){
							    		if($value[2]===$_POST["mdp"]){
							    			
							    			$valideConnection = true;

							    		}
							    	}
								}

								$erreurConnection = "Les identifiants sont incorrects...";

							}catch(PDOException  $e ){

								$erreurConnection = "Erreur de connection vers la base de données...";

							}


							if($valideConnection == true){

								//OK

								$_SESSION['connect'] = true;
								$_SESSION['pseudo'] = $_POST['pseudo'];

								echo "<script type='text/javascript'>document.location.replace('connection.php');</script>";
							
							}else{

								echo "<br><div style='color:#b00;margin:10px;'>".$erreurConnection."</div>";
								echo '<a href="connection.php">Réessayer</a><br>';
								echo '<a href="index.php">Retour à l\'accueil</a>';

							}

						}else{

							//formulaire

							include('connectForm.php');
						}

					}else{

							//vue de déconnection
							// + SESSION false
							// + redirection

						if($_GET['deco']==true){

							$_SESSION['connect'] = false;
							$_SESSION['pseudo'] = "";

							echo "<script type='text/javascript'>document.location.replace('connection.php');</script>";

						}else{

							include('connectDeco.php');

						}

					}

					

				?>				

			</div>

		</connectionDiv>

	</body>

</html>

