<?php
     
   /*
      EDIT: CASTAING Alexandre
      DATE: 10-02-2019
      Ce fichier est executé par un daemon. 
      Il permet d'effectuer un ping pour tous les sites chaque 2 minutes.
      Il enregistre l'etat des pings dans la base.
   */


   // boucle principale
    while(true) {
        
       everyTwoMinutes(); // chaque 2 minutes
        sleep(60*2);
    }

    function everyTwoMinutes(){

      echo "Pinging... \n";

      // Connection + récupere les datas de la BDD.
      // les datas sont l'id & le nom du site. 

      require("list.php");

      // boucle sur les élements 
      foreach($result as $element){

         // récupere l'id & le nom
         $id = $element[0];
         $site = $element[1];

          // retire 'http://', 'https://' et le dernier slash
         if(substr($site,0,7)=="http://"){
            $site = substr($site,7);
         }
         if(substr($site,0,8)=="https://"){
            $site = substr($site,8);
         }
         if(substr($site,-1)=="/"){
            $site = substr($site,0,-1);
         }

         // effectue le ping et récupere le code d'erreur
         $codeERR = sockAccess($site);

         // insert le code d'erreur avec l'id correspondant dans la BDD [+ le temps]
         insertBDD($id, $codeERR);

      }

    }

   function insertBDD($id, $errCode){

      try{

         // Reconnection
         require("connectionBDD.php");

         // récupere le temps (date time) de la machine
         $now = new DateTime();

         // construit la requete 
         $requete = "INSERT INTO `Etats` (idSite, Etat, time) VALUES (".$id.",'".$errCode."','".$now->format('Y-m-d H:i:s')."');";

         // execute la requete
         $sth = $bdd->prepare($requete);
         $sth->execute();

      }catch(PDOException  $e ){

         echo "erreur sql..";

      }

   }

  function sockAccess($server)
   {
      //erreur gestion
      $errno="";
      $errstr="";
      $fp=0;

      //la valeur du site à ping (str)
      $fp=fsockopen($server,80,$errno,$errstr,30);

      if($fp===0) //connection
      {
         die("Error $errstr ($errno)");
      }
      $out="GET / HTTP/1.1\r\n";
      $out.="Host: $server\r\n";
      $out.="Connection: Close\r\n\r\n";

      fwrite($fp,$out);
      $content=fgets($fp);
      $code=trim(substr($content,9,4));
      fclose($fp);

      // valeur retour
      return intval($code);
   }
