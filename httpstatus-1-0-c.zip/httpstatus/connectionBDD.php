<?php 

 	/*
      EDIT: CASTAING Alexandre
      DATE: 10-02-2019
      Simple connection à la BDD.     
   */

	try
	{
	    $bdd = new PDO('mysql:host=localhost;dbname=CASTAING_FERREIRA', 'root', 'bernardbernard');
	}
	catch (Exception $e)
	{
	    die('Erreur : ' . $e->getMessage());
	}
?>