<?php
     
   /*
      EDIT: CASTAING Alexandre
      DATE: 10-02-2019
      Ce fichier est la page d'accueil de l'application. 
      On peux voir le status des sites.
      Un Administrateur connecté peut modifier, supprimer et ajouter des sites.
 	  Tous le monde à accès à la page de connection et à l'historique d'un site.
 	  Execute le script php permettant de faire les requetes toutes les 2 minutes (à la fin du fichier) !
   */

	session_start();

	$version = "1.0.d";

	$_SESSION['connect'] = $_SESSION['connect'] ?? false;

	//Se connecte à la BDD + récupere la liste des sites (id + nom)
	require("list.php");

	// Vue HTML

?>

<meta charset="UTF-8">
<html>

	<script>
		var ListeSite = [];
	</script>

	<head>
 		 <link rel="stylesheet" type="text/css" href="form.css">
 		 <script src="jquery/jquery-3.3.1.min.js"></script>
	</head> 

	<body>

		<div class="acc">

			<?php echo "<div style='font-size:70%;'>"."Version: ".$version."</div>"; ?>

			<a href="connection.php">espace administrateur</a>
			</br>

			<?php 
				if($_SESSION['connect'] != true){
					echo "(Actuellement Déconnecté)";
				}else{
					echo "Connecté: [".$_SESSION['pseudo']."]";
					echo " - <span class='lienTextuel' id='ping'>Effectuer un ping</span>";
				}
			?>

			<script>
				
				$( "#ping" ).click(function() {

					ping();

				});


				 window.setTimeout(ping, 500);


				function ping(){

					//boucle sur tous les élements

					// todo : 
					let totalList = ListeSite.length;

					for(let i=0;i<totalList;i++){

						let elementList = ListeSite[i].name;
						let idList = ListeSite[i].id;

						$.ajax({
						  type: "POST",
						  url: "ping.php",
						  data: { "serveur": elementList, "idList": idList },
						  success: function( responseData ){

						  	// retraduit les valeurs concaténés
						  	responseData = JSON.parse(responseData);

						  	//reprendre les valeurs et inserer directements dans les divs id

						  	let textStatus = "";
						  	textStatus += "[Code "+responseData.code+"] "

						  	if(Math.trunc(responseData.code/100)==4){
						  		textStatus += "Inaccessible";
						  	}
						  	if(Math.trunc(responseData.code/100)==2){
						  		textStatus += "Accessible";
						  	}
						  	if(Math.trunc(responseData.code/100)==5){
						  		textStatus += "Erreur Serveur";
						  	}
						  	if(responseData.code==999){
						  		textStatus += "Impossible de joindre le serveur";
						  	}

						  	document.getElementById("status-"+(responseData.id)).innerHTML = (textStatus);

						  },
						  error: function( a,c,b ){
						  	console.log("err: ", b,c);
						  },
						  dataType: 'text'
						});

					}

				}

			</script>

		</div>

		<div class="Titre">
			Accueil
		</div>
	
		<div>

			<TITLEclnNom class="TITLEcln4">
					Nom de domaine / Lien
			</TITLEclnNom>

			<TITLEclnStatus class="TITLEcln4">
					Status
			</TITLEclnStatus>

		</div>

		<div>


			<?php

				// Les sites
				$i = 1;

				foreach ($result as &$value) {

					echo "<script>";
					echo "ListeSite[".($i-1)."] = {id:'".$value[0]."',name:'".$value[1]."'};";
					echo "</script>";

					$htmlList =  '<div class="line">';
					$htmlList .= '	<clnNom id="nom" class="cln4">';

					$htmlList .= '		'.$i.' - ';

					if($_SESSION['connect'] == true){
						$htmlList .= '<form action="deleteSite.php?submit=true" method="post" style="display:inline;">';
						$htmlList .= '		<input style="display:none;" name="valeur" value="'.$value[0].'"/>';
						$htmlList .= '		<input id="suppr-'.$value[0].'" name="submit" type="submit" style="color:#b00;" value="[supprimer]" />';
						$htmlList .= '</form>';
						$htmlList .= '<form action="changeSite.php" method="post" style="display:inline;">';
						$htmlList .= '		<input style="display:none;" name="valeur" value="'.$value[0].'"/>';
						$htmlList .= '		<input style="display:none;" name="name" value="'.$value[1].'"/>';
						$htmlList .= '		<input id="modif-'.$value[0].'" name="submit" type="submit" style="color:#b00;" value="[modifier]" /> ';
						$htmlList .= '</form>';
					}

					if(substr($value[1], 0, 4) == "http"){

						$htmlList .= '		<a href="'.$value[1].'" >'.$value[1].'</a>';

					}else{

						$htmlList .= '		<a href="http://'.$value[1].'" >'.$value[1].'</a>';

					}

					$htmlList .= '	</clnNom>';
					$htmlList .= '	<b><clnStatus class="cln4">';
					$htmlList .= '		<div style="display:inline-block;" id="status-'.$value[0].'">ping...</div>';

					$htmlList .= '		<div style="display:inline-block;float:right;padding-right:8px;">';
					$htmlList .= '		<form action="histoSite.php?id='.$value[0].'" method="post" style="display:inline;">';
					$htmlList .= '			<input style="display:none;" name="histo" value="'.$value[0].'"/>';
					$htmlList .= '			<input id="histo-'.$value[0].'" name="submit" type="submit" style="color:#b00;" value="[historique]" />';
					$htmlList .= '		</form></div>';

					$htmlList .= '	</clnStatus></b>';
					$htmlList .= '</div>';

					echo $htmlList;

					$i+=1;

				}

				?>

				<?php

				// Ajouter un site

				if($_SESSION['connect'] == true){

					$htmlList =  '<div class="line">';
					$htmlList .= '	<clnNom id="nom" class="cln4" style="background-color:#ff8;">';
					$htmlList .= '		<b><a href="addSite.php" > + Ajouter un site </a></b>';
					$htmlList .= '	</clnNom>';
					$htmlList .= '	<clnStatus id="status" class="cln4">';
					$htmlList .= '	</clnStatus>';
					$htmlList .= '</div>';

					echo $htmlList;
				}
				
			?>



		</div>

	</body>

</html>

<?php

//execute le script php permettant de faire les requetes toutes les 2 minutes !
	
exec("ps -e | grep -q php || php pingCRON.php &");
