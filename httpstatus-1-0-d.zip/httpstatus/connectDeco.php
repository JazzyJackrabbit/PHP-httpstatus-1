<!-- Formulaire de déconnection -->

<form action="connection.php?deco=true" method="post">

	<p>Vous êtes actuellement connecté sous <b><?php echo $_SESSION['pseudo']; ?></b></p>

	<button id="submit" name="submit" type="submit">Déconnection</button>

	</br>	</br>

	<a href="index.php">Retour à l'accueil</a>

</form>