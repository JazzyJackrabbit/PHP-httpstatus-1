CREATE DATABASE CASTAING_FERREIRA;
use CASTAING_FERREIRA;
create table Utilisateurs (
	id INT NOT NULL AUTO_INCREMENT,
	email TEXT(100) NOT NULL,
	mdp TEXT(80) NOT NULL,
	apikey TEXT(100) NOT NULL,
	PRIMARY KEY (id)
);
create table Liste (
	id INT NOT NULL AUTO_INCREMENT,
	site TEXT(1000) NOT NULL,
	PRIMARY KEY (id)
);
create table Etats (
	id INT NOT NULL AUTO_INCREMENT,
	idSite INT NOT NULL,
	Etat TEXT(50),
	Time DATETIME DEFAULT current_timestamp(),
	PRIMARY KEY (id)
);
insert into Utilisateurs (id,email,mdp,apikey) VALUES ('0','deschaussettes@yopmail.com','password','abcdefghjaimelesapis');




